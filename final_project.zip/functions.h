#ifndef INCLUDED_functions
#define INCLUDED_functions

#define _CRT_SECURE_NO_WARNINGS    // fopen 보안 경고로 인한 컴파일 에러 방지
#include <stdio.h>      // fopen, fread, fclose 함수
#include <stdlib.h>  //abs 함수
#include <string.h> //strcat, strcmp 함수
#include <unistd.h> //sleep 함수
#include <time.h> //시간측정
#define MAX 100



int attribute_txt(char *txt_name); //txt파일 검사 몇자, 몇 문장인지
int game_start(char *txt_name);
int compare(char *txt, char *input, int len);
int result();

#endif