#include "functions.h"

extern int total_line; //전체 글자수
extern int total_char; //전체 문장수
extern int total_fault; //전체 틀린 단어 개수

int main(){
    time_t start, end; //시간 측정을 위한 변수
    int total_time; //총 걸린시간
    int total_line=0; //전체 글자수 초기화
    int total_char=0; //전체 문장수 초기화
    printf("타자연습 프로그램에 오신걸 환영합니다.\n");
    printf("타자연습을 위해 원하시는 txt파일 이름을 입력해주세요(.txt 제외).\n");
    char name[20]; //입력받을 파일 이름
    char dot_txt[5]=".txt"; //.txt 그자체
    scanf("%[^\n]",name); 
    strcat(name,dot_txt); //붙혀주기
    //sleep(1);
    printf("\n선택하신 파일 검사를 시작하겠습니다.\n");
    //sleep(2);
    attribute_txt(name); //txt 파일 검사
    printf("\n타자연습 도중 중간에 그만두시고 싶으시다면 GG 혹은 gg를 입력해주세요.");
    printf("\n타자연습을 시작합니다.\n");
    /*
    for(int i=3;i>0;i--){
        printf("\n%d\n",i);
        sleep(1);
    }
    printf("시작\n");
    */
    start=time(NULL);
    game_start(name);//프로그램 시작 
    end=time(NULL);
    total_time=(double)(end - start);
    printf("%d초\n", total_time); 
    result();
    return 0;
}
