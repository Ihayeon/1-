#include "functions.h"


 int total_line=0; //전체 글자수
 int total_char=0; //전체 문장수
int total_fault=0; //전체 틀린 단어 개수
int attribute_txt(char *txt_name){
    FILE* fp = fopen(txt_name, "r");  //test파일을 r(읽기) 모드로 열기
    char buffer[MAX] = { 0, };
    if (fp==NULL){ printf("\n%s 파일을 찾을 수 없습니다.\n",txt_name);}
    
    char cha;
    while(!feof(fp))  // 파일의 끝이 아니라면
    {
        fgets(buffer, 100, fp);  // 최대 100칸짜리 한줄 읽기
        total_line+=1;
        total_char+=strlen(buffer);
    }

    printf("\n해당 %s파일은 ",txt_name);
    printf("총 %d문장, ",total_line);
    printf("%d글자입니다(공백포함).\n",total_char);
    //sleep(2);
    fclose(fp); //파일 포인터 닫기
    return 0;
}

int game_start(char *txt_name){
    FILE* fp = fopen(txt_name, "r");  //test파일을 r(읽기) 모드로 열기
    char input[100];
    char buffer[MAX] = { 0, };
    
    while(!feof(fp))  // 파일의 끝이 아니라면
    {
        fgets(buffer, 100, fp);  // 최대 100칸짜리 한줄 읽기
        buffer[strlen(buffer)-1]='\0'; //마지막 값 없애서 txt 마지막 쓰레기값 없애기
        printf("%s\n",buffer);
        scanf(" %[^\n]",input);  //앞쪽에 공백을 통해 \n 가 읽혀서 코드가 넘어가는걸 방지
        if(strcmp(input,"GG")==0){break;}
        if(strcmp(input,"gg")==0){break;}//만약 GG 혹은 gg를 입력했을경우 탈출
        printf("%s\n",input);
        total_fault+=compare(buffer,input,strlen(buffer));
        printf("%d\n",total_fault);
    }

    fclose(fp);
    return 0;
}

int compare(char *txt, char *input, int len){
    int fault=0;
    for(int i=0;i<len;i++){
        if(txt[i]!=input[i]){fault++;}  
    }
    
    if(strlen(txt)<strlen(input)){fault+=strlen(input)-strlen(txt);} //제시된 문장보다 더 오버해서 입력했을경우

    return fault;
}

int result(){
    
}
